// #include <iostream>
// #include "dnf.h"

// void foo(vector<int> x)
// {
// }

// int main()
// {
//     dnf x(3);

//     x.AddConjunction({pos, non, neg});
//     cout << x << endl;

//     // auto s = new vector<int>{1,2,3};
//     // foo(*s);
// }