#include <iostream>
#include "bdd.h"

int main()
{
    // cout << "hello from bdd" << endl;

    // bdd bdd1;
    // auto man = bdd1.GetManager();
    // auto v1 = man->CreateVertex("G1");
    // auto v2 = man->CreateVertex("G2");
    // auto v3 = man->AND_bin(v1, v2);

    // bdd1.AddRoot(v3,"v3");

    // cout << bdd1 << endl;

    // bdd1.ExportGV("bdd1");
    // auto dn = bdd1.ExportDNF();
    // for (auto d : dn)
    // {
    //     cout << d << endl;
    // }

    // man->Utilize(v1);
    // man->Utilize(v2);
}